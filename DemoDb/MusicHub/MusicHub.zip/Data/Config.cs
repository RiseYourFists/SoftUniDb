﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data 
{
    internal static class Config
    {
        private static string serverName = ".";
        private static string databaseName = "MusicHub";
        private static string serverUser = "sa";
        private static string password = "secretzone123$";

        public static string ConnectionString => GetString();

        private static string GetString()
        {
            var loginCredentials = (string.IsNullOrWhiteSpace(serverUser) || string.IsNullOrWhiteSpace(password))
                ? "Integrated Security=True;"
                : $"User={serverUser};Password={password}";
            return $"Server={serverName};Database={databaseName};{loginCredentials}";
        }
    }
}
