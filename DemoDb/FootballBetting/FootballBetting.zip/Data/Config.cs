﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data 
{
    internal static class Config
    {
        private static string serverName = ".";
        private static string databaseName = "FootballBetting";
        private static string serverUser = "";
        private static string password = "";

        public static string ConnectionString => GetString();

        private static string GetString()
        {
            var loginCredentials = (string.IsNullOrWhiteSpace(serverUser) || string.IsNullOrWhiteSpace(password))
                ? "Integrated Security=True;"
                : $"User={serverUser};Password={password}";
            return $"Server={serverName};Database={databaseName};{loginCredentials}";
        }
    }
}
