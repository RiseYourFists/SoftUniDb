﻿namespace SoftUni.Data
{
    internal static class Config
    {
        private const string serverName = "localhost,1433";
        private const string databaseName = "SoftUni";
        private const string userName = "sa";
        private const string pw = "secretzone123$";
        public static string connectionString = $"Server={serverName};Database={databaseName};User={userName};Password={pw};";
    }
}
