﻿using System;

namespace BookShop
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
